import geo.google.datamodel.GeoStatusCode;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GeoStatusCodeTest {

    @Test
    public void getCode_shouldReturnCorrectCode() {
        assertEquals(200, GeoStatusCode.G_GEO_SUCCESS.getCode());
        assertEquals(400, GeoStatusCode.G_GEO_BAD_REQUEST.getCode());
        assertEquals(500, GeoStatusCode.G_GEO_SERVER_ERROR.getCode());
        assertEquals(601, GeoStatusCode.G_GEO_MISSING_QUERY.getCode());
        assertEquals(602, GeoStatusCode.G_GEO_UNKNOWN_ADDRESS.getCode());
        assertEquals(603, GeoStatusCode.G_GEO_UNAVAILABLE_ADDRESS.getCode());
        assertEquals(604, GeoStatusCode.G_GEO_UNKNOWN_DIRECTIONS.getCode());
        assertEquals(610, GeoStatusCode.G_GEO_BAD_KEY.getCode());
        assertEquals(620, GeoStatusCode.G_GEO_TOO_MANY_QUERIES.getCode());
        assertEquals(-1, GeoStatusCode.G_GEO_UNKOWN_STATUS.getCode());
    }

    @Test
    public void getCodeName_shouldReturnCorrectCodeName() {
        assertEquals("G_GEO_SUCCESS", GeoStatusCode.G_GEO_SUCCESS.getCodeName());
        assertEquals("G_GEO_BAD_REQUEST", GeoStatusCode.G_GEO_BAD_REQUEST.getCodeName());
        assertEquals("G_GEO_SERVER_ERROR", GeoStatusCode.G_GEO_SERVER_ERROR.getCodeName());
        assertEquals("G_GEO_MISSING_QUERY", GeoStatusCode.G_GEO_MISSING_QUERY.getCodeName());
        assertEquals("G_GEO_UNKNOWN_ADDRESS", GeoStatusCode.G_GEO_UNKNOWN_ADDRESS.getCodeName());
        assertEquals("G_GEO_UNAVAILABLE_ADDRESS", GeoStatusCode.G_GEO_UNAVAILABLE_ADDRESS.getCodeName());
        assertEquals("G_GEO_UNKNOWN_DIRECTIONS", GeoStatusCode.G_GEO_UNKNOWN_DIRECTIONS.getCodeName());
        assertEquals("G_GEO_BAD_KEY", GeoStatusCode.G_GEO_BAD_KEY.getCodeName());
        assertEquals("G_GEO_TOO_MANY_QUERIES", GeoStatusCode.G_GEO_TOO_MANY_QUERIES.getCodeName());
        assertEquals("G_GEO_UNKOWN_STATUS", GeoStatusCode.G_GEO_UNKOWN_STATUS.getCodeName());
    }

    @Test
    public void getDescription_shouldReturnCorrectDescription() {
        assertEquals("No errors occurred; the address was successfully parsed and its geocode has been returned. (Since 2.55)", GeoStatusCode.G_GEO_SUCCESS.getDescription());
        assertEquals("A directions request could not be successfully parsed. (Since 2.81)", GeoStatusCode.G_GEO_BAD_REQUEST.getDescription());
        assertEquals("A geocoding or directions request could not be successfully processed, yet the exact reason for the failure is not known. (Since 2.55)", GeoStatusCode.G_GEO_SERVER_ERROR.getDescription());
        assertEquals("The HTTP q parameter was either missing or had no value. For geocoding requests, this means that an empty address was specified as input. For directions requests, this means that no query was specified in the input. (Since 2.81)", GeoStatusCode.G_GEO_MISSING_QUERY.getDescription());
        assertEquals("No corresponding geographic location could be found for the specified address. This may be due to the fact that the address is relatively new, or it may be incorrect. (Since 2.55)", GeoStatusCode.G_GEO_UNKNOWN_ADDRESS.getDescription());
        assertEquals("The geocode for the given address or the route for the given directions query cannot be returned due to legal or contractual reasons. (Since 2.55)", GeoStatusCode.G_GEO_UNAVAILABLE_ADDRESS.getDescription());
        assertEquals("The GDirections object could not compute directions between the points mentioned in the query. This is usually because there is no route available between the two points, or because we do not have data for routing in that region. (Since 2.81)", GeoStatusCode.G_GEO_UNKNOWN_DIRECTIONS.getDescription());
        assertEquals("The given key is either invalid or does not match the domain for which it was given. (Since 2.55)", GeoStatusCode.G_GEO_BAD_KEY.getDescription());
        assertEquals("The given key has gone over the requests limit in the 24 hour period. ", GeoStatusCode.G_GEO_TOO_MANY_QUERIES.getDescription());
        assertEquals("Uknown Status", GeoStatusCode.G_GEO_UNKOWN_STATUS.getDescription());
    }

    @Test
    public void getStatusCode_shouldReturnCorrectStatusCode() {
        assertEquals(GeoStatusCode.G_GEO_SUCCESS, GeoStatusCode.getStatusCode(200));
        assertEquals(GeoStatusCode.G_GEO_BAD_REQUEST, GeoStatusCode.getStatusCode(400));
        assertEquals(GeoStatusCode.G_GEO_SERVER_ERROR, GeoStatusCode.getStatusCode(500));
        assertEquals(GeoStatusCode.G_GEO_MISSING_QUERY, GeoStatusCode.getStatusCode(601));
        assertEquals(GeoStatusCode.G_GEO_UNKNOWN_ADDRESS, GeoStatusCode.getStatusCode(602));
        assertEquals(GeoStatusCode.G_GEO_UNAVAILABLE_ADDRESS, GeoStatusCode.getStatusCode(603));
        assertEquals(GeoStatusCode.G_GEO_UNKNOWN_DIRECTIONS, GeoStatusCode.getStatusCode(604));
        assertEquals(GeoStatusCode.G_GEO_BAD_KEY, GeoStatusCode.getStatusCode(610));
        assertEquals(GeoStatusCode.G_GEO_TOO_MANY_QUERIES, GeoStatusCode.getStatusCode(620));
        assertEquals(GeoStatusCode.G_GEO_UNKOWN_STATUS, GeoStatusCode.getStatusCode(-1));
    }

    @Test
    public void getStatusCode_shouldReturnGGEO_UNKOWN_STATUSForUnknownCode() {
        assertEquals(GeoStatusCode.G_GEO_UNKOWN_STATUS, GeoStatusCode.getStatusCode(9999));
    }
}